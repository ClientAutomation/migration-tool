﻿Imports System.IO
Imports System.Text
Imports System.Xml
Public Class Form2
    Dim importfile As String
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Dim importexists As Boolean = False
        Dim importdirectory As String

        ' Add any initialization after the InitializeComponent() call.
        If Form1.RBImport.Checked = True Then
            FolderBrowserDialog1.Description = "Select the directory where the export.xml file exists"
            While importexists = False
                If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
                    importdirectory = FolderBrowserDialog1.SelectedPath
                    If My.Computer.FileSystem.FileExists(importdirectory + "\export.xml") Then
                        importexists = True
                        importfile = importdirectory + "\export.xml"
                        Exit While
                    Else
                        MessageBox.Show("The file " + importdirectory + "\export.xml does not exist reselect the proper directory")
                    End If

                End If
            End While
            ButtonExport.Text = "Import Data"
            ButtonExport.Visible = True
        End If
    End Sub



    ' Updates all child tree nodes recursively.
    Private Sub CheckAllChildNodes(treeNode As TreeNode, nodeChecked As Boolean)
        Dim node As TreeNode
        For Each node In treeNode.Nodes
            node.Checked = nodeChecked
            If node.Nodes.Count > 0 Then
                ' If the current node has child nodes, call the CheckAllChildsNodes method recursively.
                Me.CheckAllChildNodes(node, nodeChecked)
            End If
        Next node
    End Sub

    ' NOTE   This code can be added to the BeforeCheck event handler instead of the AfterCheck event.
    ' After a tree node's Checked property is changed, all its child nodes are updated to the same value.
    Private Sub node_AfterCheck(sender As Object, e As TreeViewEventArgs) Handles TreeView1.AfterCheck
        ' The code only executes if the user caused the checked state to change.
        If e.Action <> TreeViewAction.Unknown AndAlso e.Node.Checked Then
            If e.Node.Nodes.Count > 0 Then
                ' Calls the CheckAllChildNodes method, passing in the current 
                ' Checked value of the TreeNode whose checked state changed. 
                Me.CheckAllChildNodes(e.Node, e.Node.Checked)
            End If
        End If
        If e.Node.Checked = True Then
            If Not e.Node.Parent Is Nothing Then
                e.Node.Parent.Checked = True
            End If
        End If
    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        wslogout()
        Application.Exit()
    End Sub

    Private Sub ButtonExport_Click(sender As Object, e As EventArgs) Handles ButtonExport.Click
        If Form1.RBexport.Checked = True Then
            Dim querylist(10000) As String
            Dim querycountlocal As Integer = 0
            Dim querydetail(13) As String
            Dim sdcountlocal As Integer = 0
            Dim sdpacklist(10000) As String
            Dim m As Integer
            Dim ExportDirectory As String
            Dim files() As String
            Dim empty As Boolean = True
            Dim found As Boolean

            FolderBrowserDialog1.Description = "Select or Create an empty directory to export data to"
            While empty = True
                If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
                    ExportDirectory = FolderBrowserDialog1.SelectedPath
                    files = System.IO.Directory.GetFiles(ExportDirectory)
                    If files.Length <> 0 Then
                        MessageBox.Show("The directory " + ExportDirectory + " is not empty reselect an empty directory")
                    Else
                        empty = False
                        Exit While
                    End If
                End If
            End While

            Dim oXML As Xml.XmlDocument
            Dim oNodes As Xml.XmlNode
            Dim oNode As Xml.XmlNode
            Dim sFilename As String = ExportDirectory + "\export.xml"
            Dim settings = New XmlWriterSettings()
            Dim textSplit() As String
            Dim gpname As String
            settings.Indent = True
            settings.NewLineOnAttributes = True
            settings.Encoding = New UTF8Encoding
            settings.IndentChars = ("  ")

            Dim writer As XmlWriter = writer.Create(sFilename, settings)

            textfile = My.Computer.FileSystem.OpenTextFileWriter(ExportDirectory + "\EngineInstance.lst", False)
            Dim InstanceList(20) As String
            Dim InstanceCount As Integer
            Dim InstFound As Boolean = False
            Dim ic As Integer
            Dim Trimchars As Char() = "|"

            writer.WriteStartDocument(True)

            writer.WriteStartElement("Exports")
            writer.WriteStartElement("Queries")
            Dim tn As TreeNode

            For Each tn In TreeView1.Nodes("Queries").Nodes
                If tn.Checked = True Then
                    parsenode(tn, writer, querylist, querycountlocal)
                End If
            Next

            For Each tn In TreeView1.Nodes("Groups").Nodes("ComputerGroups").Nodes

                If tn.Checked = True Then

                    parsegroupnode(tn, writer, querylist, querycountlocal)
                End If
            Next
            writer.WriteEndElement()
            writer.WriteStartElement("SoftwarePackages")
            For Each tn In TreeView1.Nodes("Software").Nodes
                If tn.Checked = True Then
                    ParseSDGroup(tn, writer, sdpacklist, sdcountlocal, ExportDirectory)
                End If
            Next
            writer.WriteEndElement()
            writer.WriteStartElement("QueryGroupMap")
            For Each tn In TreeView1.Nodes("Queries").Nodes
                If tn.Checked = True Then
                    writer.WriteStartElement("group")
                    writer.WriteAttributeString("name", tn.Text)
                    writer.WriteAttributeString("type", tn.Tag)

                    If tn.Tag = "Group" Then
                        writexmtree(tn, writer)
                    End If
                    writer.WriteEndElement()
                End If
            Next
            writer.WriteEndElement()

            writer.WriteStartElement("SoftwareGroupMap")
            For Each tn In TreeView1.Nodes("Software").Nodes
                If tn.Checked = True Then
                    writer.WriteStartElement("group")
                    writer.WriteAttributeString("name", tn.Text)
                    writer.WriteAttributeString("type", tn.Tag)

                    If tn.Tag = "Group" Then
                        writexmtree(tn, writer)
                    End If
                    writer.WriteEndElement()
                End If
            Next
            writer.WriteEndElement()
            writer.WriteStartElement("GroupMap")
            writer.WriteStartElement("ComputerGroupMap")
            For Each tn In TreeView1.Nodes("Groups").Nodes("ComputerGroups").Nodes
                If tn.Checked = True Then
                    gpname = tn.Text

                    If gpname.Contains("=") = True Then

                        textSplit = gpname.Split("|")

                        gpname = textSplit(0).Trim
                    End If
                    writer.WriteStartElement("group")
                    writer.WriteAttributeString("name", gpname)
                    writer.WriteAttributeString("type", tn.Tag)
                    ' Public CompGroupNames(10000, 6) As String 'groupLabel, groupUUID, queryLabel, queryUUID, engineLabel, evaluationFrequency
                    'Public TotalUnitGroupCount As Integer = 0 'for computergroupnames

                    If tn.Tag = "Group" Then

                        Dim spliter() As String

                        For m = 0 To TotalUnitGroupCount - 1
                            spliter = Split(CompGroupNames(m, 0), "|")
                            spliter(0) = spliter(0).TrimEnd(Trimchars)

                            If gpname = spliter(0) Then


                                writer.WriteAttributeString("queryLabel", CompGroupNames(m, 2))
                                writer.WriteAttributeString("engineLabel", CompGroupNames(m, 5))
                                writer.WriteAttributeString("evaluationFrequency", CompGroupNames(m, 6))
                                writer.WriteAttributeString("Parent", CompGroupNames(m, 7))

                                Exit For
                            End If
                        Next

                        WriteCompGroupXML(tn, writer)
                    End If
                    writer.WriteEndElement()
                End If




            Next

            writer.WriteEndElement()
            writer.WriteEndElement()
            writer.WriteEndElement()
            writer.WriteEndDocument()
            writer.Close()
            textfile.Close()
        Else
            import()
        End If

    End Sub
    Private Sub import()
        'import section


        Dim fragment(0) As clientauto.QueryFragment2
        Dim xmlDoc As New XmlDocument()
        xmlDoc.Load(importfile)

        'Queries
        Dim queryName As String
        Dim queryTable As String
        Dim queryTableLabelPrimaryKey As String
        Dim queryTableLabelSecondaryKey As String
        Dim queryTableLabelField As String
        Dim queryType As String
        Dim q As Integer
        Dim queryfound As Boolean
        Dim querynodes As XmlNodeList = xmlDoc.DocumentElement.SelectNodes("/Exports/Queries")
        Dim quuid As String

        Dim node As XmlNode
        Dim node1 As XmlNode

        For Each node In querynodes
            For Each node1 In node

                queryfound = False
                queryName = node1.Attributes("name").Value
                queryTable = (node1.Attributes("queryTable").Value)
                queryTableLabelPrimaryKey = (node1.Attributes("queryTableLabelPrimaryKey").Value)
                queryTableLabelSecondaryKey = (node1.Attributes("queryTableLabelSecondaryKey").Value)
                queryTableLabelField = (node1.Attributes("queryTableLabelField").Value)
                queryType = (node1.Attributes("queryType").Value)

                fragment(0) = New clientauto.QueryFragment2 With {
                    .linkQueryName = (node1.Attributes("linkQueryName").Value),
                    .pseudoStatement = (node1.Attributes("pseudoStatement").Value),
                    .queryFragmentType = (node1.Attributes("queryFragmentType").Value),
                    .searchRecursive = (node1.Attributes("searchRecursive").Value),
                    .searchRecursiveSupplied = (node1.Attributes("searchRecursiveSupplied").Value),
                    .statement = (node1.Attributes("statement").Value)}


                For q = 0 To QueryCount
                    If QueryNames(q, 0) = queryName Then
                        queryfound = True

                        Exit For
                    End If
                Next
                If queryfound = False Then

                    quuid = WSImportQuery(queryName, queryTable, queryTableLabelField, queryTableLabelPrimaryKey, queryTableLabelSecondaryKey, queryType, fragment)
                    If quuid <> "Not OK" Then
                        QueryNames(QueryCount + 1, 1) = quuid
                        QueryNames(QueryCount + 1, 0) = queryName
                        QueryCount = QueryCount + 1

                    Else
                        MessageBox.Show("unable to create query" + queryName)
                    End If
                End If

            Next
        Next

        'packages
        querynodes = xmlDoc.DocumentElement.SelectNodes("/Exports/SoftwarePackages")
        Dim packname As String
        Dim packver As String
        Dim packpath As String
        Dim puuid As String
        Dim packfound As Boolean = False
        For Each node In querynodes
            packfound = False
            For Each node1 In node
                packname = node1.Attributes("name").Value
                packver = node1.Attributes("version").Value
                packpath = node1.Attributes("directory").Value
                For q = 0 To TotalpackageCount

                    If packageinfo(q, 0) = packname And packageinfo(q, 1) = packver Then
                        packfound = True
                        Exit For
                    End If
                Next
                If packfound = False Then
                    puuid = WSimportPackage(packpath)
                    If puuid <> "Not OK" Then
                        packageinfo(TotalpackageCount + 1, 0) = packname
                        packageinfo(TotalpackageCount + 1, 1) = packver
                        packageinfo(TotalpackageCount + 1, 2) = puuid
                    End If

                End If

            Next
        Next


        'sdgroups
        querynodes = xmlDoc.DocumentElement.SelectNodes("/Exports/SoftwareGroupMap")
        For Each node In querynodes

            ParseSDGroupXML(node, "")
        Next
        'computerGroups
        querynodes = xmlDoc.DocumentElement.SelectNodes("/Exports/GroupMap/ComputerGroupMap")

        For Each node1 In querynodes



            ParseComputerGroupXML(node1, "")

        Next
    End Sub
    Sub instFileWriter(instanceName As String, Filewriter As StreamWriter)

        Dim InstFound As Boolean = False
        Dim IC As Integer
        For IC = 0 To EngineCount - 1


            If EngineInstanceList(IC) = instanceName Then
                InstFound = True
                Exit For

            End If
        Next
        If InstFound = False Then

            EngineInstanceList(EngineCount) = instanceName
                EngineCount = EngineCount + 1
                Filewriter.WriteLine(instanceName)
            Else

        End If



    End Sub
    Sub ParseSDGroupXML(node As XmlNode, parent As String)

        Dim Name As String
        Dim parentGuuid As String = Nothing
        Dim targetguuid As String = ""
        Dim type As String
        Dim ver As String
        Dim c As Integer
        Dim ret As String
        If parent <> "" Then

            For c = 0 To TotalSoftwarGroupCount - 1
                If SoftwareGroupNames(c, 0) = parent Then
                    parentGuuid = SoftwareGroupNames(c, 1)
                    Exit For
                End If
            Next
        Else
            parentGuuid = Nothing

        End If
        If parent <> "" Then
            For Each node In node
                targetguuid = Nothing
                Name = node.Attributes("name").Value
                type = node.Attributes("type").Value

                If type = "Group" Then

                    For c = 0 To TotalSoftwarGroupCount - 1

                        If Name = SoftwareGroupNames(c, 0) Then
                            targetguuid = SoftwareGroupNames(c, 1)

                            Exit For
                        End If
                    Next


                    If targetguuid = "" Then

                        targetguuid = WSCreateSoftwareGroup(Name, parentGuuid)
                        SoftwareGroupNames(TotalSoftwarGroupCount + 1, 0) = Name
                        SoftwareGroupNames(TotalSoftwarGroupCount + 1, 1) = targetguuid
                        TotalSoftwarGroupCount = TotalSoftwarGroupCount + 1
                    Else
                        ret = WSIsSDGroupInGroup(Name, parentGuuid)
                        If ret = "NotFound" Then
                            WSLinkSoftwarGroupToGroup(Name, parentGuuid)
                        End If

                        ParseSDGroupXML(node, Name)
                    End If

                Else
                    Dim mysplit() As String = Name.Split("'")
                    Name = mysplit(0)
                    ver = mysplit(1)

                    ret = WSISpackageInGroup(Name, ver, parentGuuid)

                    If ret = "NotFound" Then

                        WSLinkPackageToGroup(Name, ver, parent)


                    End If

                End If
            Next
        End If
    End Sub
    Sub ParseComputerGroupXML(node As XmlNode, parent As String)
        Dim GroupName As String
        Dim type As String
        Dim queryLabel As String
        Dim engineLabel As String
        Dim evaluationFrequency As String

        Dim GroupExists As Boolean
        Dim GroupLinked As Boolean
        Dim j As Integer
        Dim NewGroupUUID As String
        Dim GroupNameArray(0) As String
        For Each node In node
            GroupExists = False
            GroupLinked = False
            GroupName = node.Attributes("name").Value
            type = node.Attributes("type").Value
            queryLabel = node.Attributes("queryLabel").Value
            engineLabel = node.Attributes("engineLabel").Value
            evaluationFrequency = node.Attributes("evaluationFrequency").Value
            'checking if group already exists

            For j = 0 To TotalUnitGroupCount - 1
                If GroupName = CompGroupNames(j, 0) Then
                    GroupExists = True
                    'checking to see if group is linked
                    If parent = CompGroupNames(j, 7) Then
                        GroupLinked = True
                        Exit For
                    End If
                End If
            Next
            If GroupExists = False Then

                NewGroupUUID = WSCreateUnitGroupbyname(GroupName, engineLabel, queryLabel, evaluationFrequency, parent)
                If NewGroupUUID <> "" Then

                    CompGroupNames(TotalUnitGroupCount, 0) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 1) = NewGroupUUID
                    CompGroupNames(TotalUnitGroupCount, 2) = queryLabel
                    CompGroupNames(TotalUnitGroupCount, 3) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 4) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 5) = engineLabel
                    CompGroupNames(TotalUnitGroupCount, 6) = evaluationFrequency
                    CompGroupNames(TotalUnitGroupCount, 7) = parent
                    TotalUnitGroupCount = TotalUnitGroupCount + 1
                End If
            ElseIf GroupLinked = False Then

                GroupNameArray(0) = GroupName
                NewGroupUUID = WSLinkUnitGroup(parent, GroupNameArray)
                If NewGroupUUID = "OK" Then

                    CompGroupNames(TotalUnitGroupCount, 0) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 1) = NewGroupUUID
                    CompGroupNames(TotalUnitGroupCount, 2) = queryLabel
                    CompGroupNames(TotalUnitGroupCount, 3) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 4) = GroupName
                    CompGroupNames(TotalUnitGroupCount, 5) = engineLabel
                    CompGroupNames(TotalUnitGroupCount, 6) = evaluationFrequency
                    CompGroupNames(TotalUnitGroupCount, 7) = parent
                    TotalUnitGroupCount = TotalUnitGroupCount + 1
                End If

            End If

            If type = "Group" Then
                ParseComputerGroupXML(node, node.Attributes("name").Value)
            End If
        Next







    End Sub
    Sub WriteCompGroupXML(tn As TreeNode, writer As XmlWriter)
        Dim tn1 As TreeNode
        Dim gpname As String

        Dim textsplit() As String
        For Each tn1 In tn.Nodes
            If tn1.Checked = True Then
                gpname = tn1.Text

                If gpname.Contains("=") = True Then

                    textsplit = gpname.Split("Query=")

                    gpname = textsplit(0).Trim
                End If
                writer.WriteStartElement("group")
                writer.WriteAttributeString("name", gpname)
                writer.WriteAttributeString("type", tn1.Tag)
                    ' Public CompGroupNames(10000, 6) As String 'groupLabel, groupUUID, queryLabel, queryUUID, engineLabel, evaluationFrequency
                    'Public TotalUnitGroupCount As Integer = 0 'for computergroupnames
                    If tn1.Tag = "Group" Then
                        For m = 0 To TotalUnitGroupCount - 1
                            If tn1.Text = CompGroupNames(m, 0) Then
                                writer.WriteAttributeString("queryLabel", CompGroupNames(m, 2))
                                writer.WriteAttributeString("engineLabel", CompGroupNames(m, 5))
                                writer.WriteAttributeString("evaluationFrequency", CompGroupNames(m, 6))
                            writer.WriteAttributeString("Parent", CompGroupNames(m, 7))
                            instFileWriter(CompGroupNames(m, 5), textfile)
                            Exit For
                        End If
                        Next

                        WriteCompGroupXML(tn1, writer)
                    End If
                    writer.WriteEndElement()
                End If
        Next
    End Sub

    Sub writexmtree(tn As TreeNode, writer As XmlWriter)
        Dim tn1 As TreeNode
        For Each tn1 In tn.Nodes
            If tn1.Checked = True Then
                writer.WriteStartElement("group")
                writer.WriteAttributeString("name", tn1.Text)
                writer.WriteAttributeString("type", tn1.Tag)

                If tn1.Tag = "Group" Then
                    writexmtree(tn1, writer)
                End If
                writer.WriteEndElement()
            End If
        Next
    End Sub
    Sub ParseSDGroup(tn As TreeNode, writer As XmlWriter, ByRef sdpacklist() As String, ByRef sdcountlocal As Integer, dirpath As String)
        Dim tn1 As TreeNode

        If tn.Tag <> "Group then" Then

            WriteSDXML(tn.Text, writer, sdpacklist, sdcountlocal, dirpath)
        End If
        For Each tn1 In tn.Nodes

            If tn1.Checked = True Then

                If tn1.Tag <> "Group then" Then

                    WriteSDXML(tn1.Text, writer, sdpacklist, sdcountlocal, dirpath)
                Else
                    ParseSDGroup(tn1, writer, sdpacklist, sdcountlocal, dirpath)
                End If
            End If
        Next

    End Sub
    Sub WriteSDXML(packagename As String, writer As XmlWriter, ByRef sdpacklist() As String, ByRef sdlocalcount As Integer, dirpath As String)
        Dim rtn As String
        Dim m As Integer
        Dim found As Boolean = False
        Dim sdpackagename As String
        Dim sdversion As String
        Dim packageuuid As String
        Dim packagedirectory As String
        For m = 0 To sdlocalcount

            If packagename = sdpacklist(m) Then
                found = True
                Exit For
            End If
        Next
        If found = False Then
            found = True
            For m = 0 To TotalpackageCount

                If packagename = packageinfo(m, 2) Then
                    sdpackagename = packageinfo(m, 0)
                    sdversion = packageinfo(m, 1)
                    packageuuid = packageinfo(m, 3)
                    packagedirectory = dirpath + "\" + packagename
                    Directory.CreateDirectory(packagedirectory)
                    rtn = WSExportSDPackage(packageuuid, packagedirectory)
                    If rtn = "OK" Then
                        writer.WriteStartElement("package")
                        writer.WriteAttributeString("name", sdpackagename)
                        writer.WriteAttributeString("version", sdversion)
                        writer.WriteAttributeString("directory", packagedirectory)
                        writer.WriteEndElement()
                    End If
                    found = False
                    Exit For
                End If
            Next

        End If
    End Sub
    Sub WriteQueryXML(QuerryUUID As String, writer As XmlWriter)
        Dim QueryDetails(12) As String
        QueryDetails = wsGetQuery(QuerryUUID)
        If QueryDetails(6) <> "" Then
            Dim j As Integer
            For j = 0 To QueryCount
                If QueryDetails(0) = QueryNames(j, 0) Then
                    WriteQueryXML(QueryNames(j, 1), writer)
                    Exit For
                End If
            Next
        End If
        If QueryDetails(7).Contains("Link Query") Then
            Dim mysplit() As String
            Dim count1 As Integer
            mysplit = QueryDetails(7).Split("'")
            For count1 = 0 To mysplit.Length - 1
                If mysplit(count1).Contains("Link Query") Then
                    Dim j1 As Integer
                    For j1 = 0 To QueryCount
                        If QueryNames(j1, 0) = mysplit(count1 + 1) Then
                            WriteQueryXML(QueryNames(j1, 1), writer)
                            Exit For
                        End If
                    Next
                End If

            Next
        End If

        writer.WriteStartElement("query")

        writer.WriteAttributeString("name", QueryDetails(0))
        writer.WriteAttributeString("queryTable", QueryDetails(1))

        writer.WriteAttributeString("queryTableLabelPrimaryKey", QueryDetails(2))
        writer.WriteAttributeString("queryTableLabelSecondaryKey", QueryDetails(3))
        writer.WriteAttributeString("queryTableLabelField", QueryDetails(4))
        writer.WriteAttributeString("queryType", QueryDetails(5))
        'convert back to fragments
        writer.WriteAttributeString("linkQueryName", QueryDetails(6))
        writer.WriteAttributeString("pseudoStatement", QueryDetails(7))
        writer.WriteAttributeString("queryFragmentType", QueryDetails(8))
        writer.WriteAttributeString("searchRecursive", QueryDetails(9))
        writer.WriteAttributeString("searchRecursiveSupplied", QueryDetails(10))
        writer.WriteAttributeString("statement", QueryDetails(11))
        'end fragments




        writer.WriteEndElement()




    End Sub





    Sub parsenode(tn As TreeNode, writer As XmlWriter, ByRef querylist() As String, ByRef querycountlocal As Integer)
        Dim tn1 As TreeNode
        Dim m As Integer
        Dim found As Boolean
        For Each tn1 In tn.Nodes
            found = False
            If tn1.Checked = True Then

                If tn1.Tag <> "Group" Then

                    For m = 0 To querycountlocal
                        If tn1.Text = querylist(m) Then
                            found = True
                            Exit For
                        End If
                    Next
                    If found = False Then
                        For m = 0 To QueryCount - 1
                            If QueryNames(m, 0) = tn1.Text Then
                                WriteQueryXML(QueryNames(m, 1), writer)
                                querylist(querycountlocal) = tn1.Text
                                querycountlocal = querycountlocal + 1
                                Exit For
                            End If
                        Next

                    End If

                Else
                    parsenode(tn1, writer, querylist, querycountlocal)

                End If
            End If
        Next
    End Sub
    Sub parsegroupnode(tn As TreeNode, writer As XmlWriter, ByRef querylist() As String, ByRef querycountlocal As Integer)
        Dim tn1 As TreeNode
        If tn.Checked = True Then

            If tn.Tag = "Group" Then

                If InStr(tn.Text, "=") > 0 Then
                    dogetquery(tn, writer, querylist, querycountlocal)

                End If
            End If
        End If

        For Each tn1 In tn.Nodes


            If tn1.Checked = True Then

                If tn1.Tag = "Group" Then

                    If InStr(tn1.Text, "=") > 0 Then
                        dogetquery(tn1, writer, querylist, querycountlocal)

                    End If
                End If
            End If

            parsegroupnode(tn1, writer, querylist, querycountlocal)



        Next
    End Sub

    Sub dogetquery(tn As TreeNode, writer As XmlWriter, ByRef querylist() As String, ByRef querycountlocal As Integer)
        Dim m As Integer
        Dim found As Boolean = False
        Dim qname As String
        Dim qsplit() As String
        qsplit = tn.Text.Split("Query=")

        For m = 0 To querycountlocal
            If qsplit(1) = querylist(m) Then
                found = True
                Exit For
            End If
        Next
        If found = False Then
            For m = 0 To TotalUnitGroupCount - 1
                If CompGroupNames(m, 0) = tn.Text Then
                    WriteQueryXML(CompGroupNames(m, 3), writer)
                    querylist(querycountlocal) = Strings.Left(tn.Text, InStr(tn.Text, "=") - 1)
                    querycountlocal = querycountlocal + 1
                    Exit For
                End If

            Next
        End If
    End Sub

End Class