﻿Public Class Form1
    Private Sub RBImport_CheckedChanged(sender As Object, e As EventArgs) Handles RBImport.CheckedChanged
        If RBImport.Checked = True Then
            RBexport.Checked = False
            GBoxCredentials.Visible = True
        End If
    End Sub

    Private Sub RBexport_CheckedChanged(sender As Object, e As EventArgs) Handles RBexport.CheckedChanged
        If RBexport.Checked = True Then
            RBImport.Checked = False
            GBoxCredentials.Visible = True
        End If
    End Sub

    Private Sub TB_HostName_TextChanged(sender As Object, e As EventArgs) Handles TB_HostName.TextChanged, TB_Password.TextChanged, TB_User.TextChanged
        LabelInvalid.Visible = False
        ButtonValidate.Visible = True
    End Sub

    Private Sub ButtonValidate_Click(sender As Object, e As EventArgs) Handles ButtonValidate.Click

        Dim rtn1 As String
        WSLogin(TB_HostName.Text)
        BeginningSoftwareGroupPointer = 0
        BeginningQueryGroupPointer = 0
        BeginningGroupPointer = 0
        If SessionID = "" Then
            LabelInvalid.Visible = True

        Else
            Dim done As Boolean = False
            Dim CurrentNode As String = "Software"
            Dim CurrentGroupUUID As String = Nothing
            Dim counter As Integer
            Dim m As Integer

            Dim pointer As Integer = 0
            Dim packagearray() As String
            Dim rtn As String
            Dim QueriesInGroup() As String
            Dim GroupsInGroup() As String
            Form2.Show()
            If RBexport.Checked = True Then
                Form2.TreeView1.Visible = True
            End If
            rtn = WSGetAllSoftware(Nothing, True, packagearray)
            Form2.TreeView1.Nodes.Add(CurrentNode, CurrentNode)
            Form2.TreeView1.Nodes(CurrentNode).Tag = "Group"
            Form2.TreeView1.Nodes(CurrentNode).ImageIndex = 1
            Form2.TreeView1.Nodes(CurrentNode).SelectedImageIndex = 1
            MySelectedNode = Form2.TreeView1.Nodes.Find(CurrentNode, True)
            Form2.TreeView1.SelectedNode = MySelectedNode(0)

            counter = WSGetSoftwareGroups(CurrentGroupUUID)
            For m = BeginningSoftwareGroupPointer To BeginningSoftwareGroupPointer + counter - 1
                Form2.TreeView1.SelectedNode.Nodes.Add(SoftwareGroupNames(m, 0), SoftwareGroupNames(m, 0))
                Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).Tag = "Group"
                Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).ImageIndex = 1
                Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).SelectedImageIndex = 1
            Next
            BeginningSoftwareGroupPointer = BeginningSoftwareGroupPointer + counter
            While pointer < BeginningSoftwareGroupPointer

                counter = 0
                CurrentGroupUUID = SoftwareGroupNames(pointer, 1)

                counter = WSGetSoftwareGroups(CurrentGroupUUID)

                MySelectedNode = Form2.TreeView1.Nodes.Find(SoftwareGroupNames(pointer, 0), True)
                Form2.TreeView1.SelectedNode = MySelectedNode(0)
                If counter > 0 Then
                    For m = BeginningSoftwareGroupPointer To BeginningSoftwareGroupPointer + counter - 1
                        Form2.TreeView1.SelectedNode.Nodes.Add(SoftwareGroupNames(m, 0), SoftwareGroupNames(m, 0))
                        Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).Tag = "Group"
                        Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).ImageIndex = 1
                        Form2.TreeView1.SelectedNode.Nodes(SoftwareGroupNames(m, 0)).SelectedImageIndex = 1
                    Next
                    BeginningSoftwareGroupPointer = BeginningSoftwareGroupPointer + counter

                End If
                rtn = WSGetAllSoftware(CurrentGroupUUID, False, packagearray)
                If rtn = "OK" Then
                    For m = 0 To packagearray.Length - 1
                        Form2.TreeView1.SelectedNode.Nodes.Add(packagearray(m), packagearray(m))

                    Next
                End If
                pointer = pointer + 1
            End While
            'queries
            WSGetAllQueries()
            BeginningGroupPointer = 0
            pointer = 0
            Form2.TreeView1.Nodes.Add("Queries", "Queries")
            Form2.TreeView1.Nodes("Queries").Tag = "Group"
            Form2.TreeView1.Nodes("Queries").ImageIndex = 1
            Form2.TreeView1.Nodes("Queries").SelectedImageIndex = 1
            Form2.TreeView1.Nodes("Queries").Nodes.Add("All Queries", "All Queries")
            Form2.TreeView1.Nodes("Queries").Nodes("All Queries").Tag = "Group"
            Form2.TreeView1.Nodes("Queries").Nodes("All Queries").ImageIndex = 1
            Form2.TreeView1.Nodes("Queries").Nodes("All Queries").SelectedImageIndex = 1
            For m = 0 To QueryCount - 1
                Form2.TreeView1.Nodes("Queries").Nodes("All Queries").Nodes.Add(QueryNames(m, 0), QueryNames(m, 0))

            Next


            MySelectedNode = Form2.TreeView1.Nodes.Find("Queries", True)
            Form2.TreeView1.SelectedNode = MySelectedNode(0)
            counter = WSGetQueryGroups(0)
            For m = 0 To counter - 1

                Form2.TreeView1.SelectedNode.Nodes.Add(QueryGroupNames(m, 0), QueryGroupNames(m, 0))

                Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).Tag = "Group"
                Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).ImageIndex = 1
                Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).SelectedImageIndex = 1
            Next

            BeginningQueryGroupPointer = BeginningQueryGroupPointer + counter
            pointer = 0
            While pointer < BeginningQueryGroupPointer

                counter = 0
                CurrentGroupUUID = QueryGroupNames(pointer, 1)

                counter = WSGetQueryGroups(CurrentGroupUUID)

                MySelectedNode = Form2.TreeView1.Nodes.Find(QueryGroupNames(pointer, 0), True)
                Form2.TreeView1.SelectedNode = MySelectedNode(0)
                If counter > 0 Then
                    For m = BeginningQueryGroupPointer To BeginningQueryGroupPointer + counter - 1
                        Form2.TreeView1.SelectedNode.Nodes.Add(QueryGroupNames(m, 0), QueryGroupNames(m, 0))
                        Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).Tag = "Group"
                        Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).ImageIndex = 1
                        Form2.TreeView1.SelectedNode.Nodes(QueryGroupNames(m, 0)).SelectedImageIndex = 1
                    Next
                    BeginningQueryGroupPointer = BeginningQueryGroupPointer + counter


                End If
                counter = 0
                counter = WSGetQueriesInGroup(CLng(CurrentGroupUUID), QueriesInGroup)
                If counter > 0 Then
                    For m = 0 To counter - 1
                        Form2.TreeView1.SelectedNode.Nodes.Add(QueriesInGroup(m), QueriesInGroup(m))
                        Form2.TreeView1.SelectedNode.Nodes(QueriesInGroup(m)).Tag = "Query"
                        Form2.TreeView1.SelectedNode.Nodes(QueriesInGroup(m)).ImageIndex = 0
                        Form2.TreeView1.SelectedNode.Nodes(QueriesInGroup(m)).SelectedImageIndex = 0
                    Next
                End If
                BeginningItemPointer = BeginningItemPointer + counter
                pointer = pointer + 1
            End While







            Form2.TreeView1.SelectedNode = Nothing
            'groups



            Form2.TreeView1.Nodes.Add("Groups", "Groups")
            Form2.TreeView1.Nodes("Groups").Tag = "Group"
            Form2.TreeView1.Nodes("Groups").ImageIndex = 1
            Form2.TreeView1.Nodes("Groups").SelectedImageIndex = 1
            'computer groups
            Form2.TreeView1.Nodes("Groups").Nodes.Add("ComputerGroups", "ComputerGroups")
            Form2.TreeView1.Nodes("Groups").Nodes("ComputerGroups").Tag = "Group"
            Form2.TreeView1.Nodes("Groups").Nodes("ComputerGroups").ImageIndex = 1
            Form2.TreeView1.Nodes("Groups").Nodes("ComputerGroups").SelectedImageIndex = 1

            MySelectedNode = Form2.TreeView1.Nodes.Find("ComputerGroups", True)
            Form2.TreeView1.SelectedNode = MySelectedNode(0)
            BeginningGroupPointer = 0
            BeginningItemPointer = 0
            pointer = 0
            counter = 0

            CurrentGroupUUID = WSGetAllComputerUUID()
            counter = WSGetGroupsInGroup(CurrentGroupUUID, "$AllComputer")
            If counter > 0 Then
                For m = 0 To counter - 1

                    Form2.TreeView1.SelectedNode.Nodes.Add(CompGroupNames(m, 0), CompGroupNames(m, 0))
                    Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).Tag = "Group"
                    Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).ImageIndex = 1
                    Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).SelectedImageIndex = 1

                Next
            End If

            BeginningGroupPointer = BeginningGroupPointer + counter
            counter = 0
            'counter = WSGetComputersInGroup(CurrentGroupUUID)
            'If counter > 0 Then
            'For m = 0 To counter - 1

            'Form2.TreeView1.SelectedNode.Nodes.Add(ComputerNames(m, 0), ComputerNames(m, 0))
            'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).Tag = "Item"
            'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).ImageIndex = 0
            'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).SelectedImageIndex = 0
            'Next
            'End If
            '   BeginningItemPointer = BeginningItemPointer + counter
            While pointer < BeginningGroupPointer
                rtn1 = TXtSplitter(CompGroupNames(pointer, 0))

                '  counter = 0
                CurrentGroupUUID = CompGroupNames(pointer, 1)

                counter = WSGetGroupsInGroup(CurrentGroupUUID, rtn1)
                MySelectedNode = Form2.TreeView1.Nodes("Groups").Nodes("ComputerGroups").Nodes.Find(CompGroupNames(pointer, 0), True)
                Form2.TreeView1.SelectedNode = MySelectedNode(0)

                If counter > 0 Then
                    For m = BeginningGroupPointer To BeginningGroupPointer + counter - 1

                        Form2.TreeView1.SelectedNode.Nodes.Add(CompGroupNames(m, 0), CompGroupNames(m, 0))
                        Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).Tag = "Group"
                        Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).ImageIndex = 1
                        Form2.TreeView1.SelectedNode.Nodes(CompGroupNames(m, 0)).SelectedImageIndex = 1
                    Next
                    BeginningGroupPointer = BeginningGroupPointer + counter
                End If
                ''     counter = WSGetComputersInGroup(CurrentGroupUUID)
                'If counter > 0 Then
                'For m = BeginningItemPointer To counter - 1
                '
                'Form2.TreeVie 'w1.SelectedNode.Nodes.Add(ComputerNames(m, 0), ComputerNames(m, 0))
                'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).Tag = "Item"
                'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).ImageIndex = 0
                'Form2.TreeView1.SelectedNode.Nodes(ComputerNames(m, 0)).SelectedImageIndex = 0
                'Next
                'End If
                '   BeginningItemPointer = BeginningItemPointer + counter
                pointer = pointer + 1
            End While







            Form2.TreeView1.CollapseAll()


            Me.Hide()
        End If



    End Sub
    Function Stringsplit(instring As String) As String
        Stringsplit = Nothing
        Dim stringarray() As String = Split(instring)
        Dim i As Integer
        For i = 0 To stringarray.Length - 1
            Stringsplit = Stringsplit + "Nodes(" + stringarray(i) + "."
        Next
    End Function
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        If SessionID.ToString <> "" Then
            wslogout()
        End If
        Application.Exit()
    End Sub
End Class
