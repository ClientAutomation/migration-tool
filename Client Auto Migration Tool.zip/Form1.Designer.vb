﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GBMode = New System.Windows.Forms.GroupBox()
        Me.RBexport = New System.Windows.Forms.RadioButton()
        Me.RBImport = New System.Windows.Forms.RadioButton()
        Me.GBoxCredentials = New System.Windows.Forms.GroupBox()
        Me.LabelInvalid = New System.Windows.Forms.Label()
        Me.ButtonValidate = New System.Windows.Forms.Button()
        Me.LBpassword = New System.Windows.Forms.Label()
        Me.LBUser = New System.Windows.Forms.Label()
        Me.LBHostName = New System.Windows.Forms.Label()
        Me.TB_Password = New System.Windows.Forms.TextBox()
        Me.TB_User = New System.Windows.Forms.TextBox()
        Me.TB_HostName = New System.Windows.Forms.TextBox()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GBMode.SuspendLayout()
        Me.GBoxCredentials.SuspendLayout()
        Me.SuspendLayout()
        '
        'GBMode
        '
        Me.GBMode.Controls.Add(Me.TextBox1)
        Me.GBMode.Controls.Add(Me.RBexport)
        Me.GBMode.Controls.Add(Me.RBImport)
        Me.GBMode.Location = New System.Drawing.Point(112, 24)
        Me.GBMode.Name = "GBMode"
        Me.GBMode.Size = New System.Drawing.Size(200, 67)
        Me.GBMode.TabIndex = 0
        Me.GBMode.TabStop = False
        Me.GBMode.Text = "Select 1"
        '
        'RBexport
        '
        Me.RBexport.AutoSize = True
        Me.RBexport.Location = New System.Drawing.Point(35, 35)
        Me.RBexport.Name = "RBexport"
        Me.RBexport.Size = New System.Drawing.Size(55, 17)
        Me.RBexport.TabIndex = 3
        Me.RBexport.Text = "Export"
        Me.RBexport.UseVisualStyleBackColor = True
        '
        'RBImport
        '
        Me.RBImport.AutoSize = True
        Me.RBImport.Location = New System.Drawing.Point(35, 12)
        Me.RBImport.Name = "RBImport"
        Me.RBImport.Size = New System.Drawing.Size(54, 17)
        Me.RBImport.TabIndex = 2
        Me.RBImport.Text = "Import"
        Me.RBImport.UseVisualStyleBackColor = True
        '
        'GBoxCredentials
        '
        Me.GBoxCredentials.Controls.Add(Me.LabelInvalid)
        Me.GBoxCredentials.Controls.Add(Me.ButtonValidate)
        Me.GBoxCredentials.Controls.Add(Me.LBpassword)
        Me.GBoxCredentials.Controls.Add(Me.LBUser)
        Me.GBoxCredentials.Controls.Add(Me.LBHostName)
        Me.GBoxCredentials.Controls.Add(Me.TB_Password)
        Me.GBoxCredentials.Controls.Add(Me.TB_User)
        Me.GBoxCredentials.Controls.Add(Me.TB_HostName)
        Me.GBoxCredentials.Location = New System.Drawing.Point(7, 97)
        Me.GBoxCredentials.Name = "GBoxCredentials"
        Me.GBoxCredentials.Size = New System.Drawing.Size(341, 172)
        Me.GBoxCredentials.TabIndex = 1
        Me.GBoxCredentials.TabStop = False
        Me.GBoxCredentials.Text = "Client Auto Credientials"
        Me.GBoxCredentials.Visible = False
        '
        'LabelInvalid
        '
        Me.LabelInvalid.AutoSize = True
        Me.LabelInvalid.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelInvalid.ForeColor = System.Drawing.Color.Crimson
        Me.LabelInvalid.Location = New System.Drawing.Point(22, 116)
        Me.LabelInvalid.Name = "LabelInvalid"
        Me.LabelInvalid.Size = New System.Drawing.Size(170, 13)
        Me.LabelInvalid.TabIndex = 7
        Me.LabelInvalid.Text = "Invalid Credentials Try Again"
        Me.LabelInvalid.Visible = False
        '
        'ButtonValidate
        '
        Me.ButtonValidate.Location = New System.Drawing.Point(220, 116)
        Me.ButtonValidate.Name = "ButtonValidate"
        Me.ButtonValidate.Size = New System.Drawing.Size(75, 47)
        Me.ButtonValidate.TabIndex = 6
        Me.ButtonValidate.Text = "Validate Credentials"
        Me.ButtonValidate.UseVisualStyleBackColor = True
        '
        'LBpassword
        '
        Me.LBpassword.AutoSize = True
        Me.LBpassword.Location = New System.Drawing.Point(22, 72)
        Me.LBpassword.Name = "LBpassword"
        Me.LBpassword.Size = New System.Drawing.Size(53, 13)
        Me.LBpassword.TabIndex = 5
        Me.LBpassword.Text = "Password"
        '
        'LBUser
        '
        Me.LBUser.AutoSize = True
        Me.LBUser.Location = New System.Drawing.Point(22, 46)
        Me.LBUser.Name = "LBUser"
        Me.LBUser.Size = New System.Drawing.Size(29, 13)
        Me.LBUser.TabIndex = 4
        Me.LBUser.Text = "User"
        '
        'LBHostName
        '
        Me.LBHostName.AutoSize = True
        Me.LBHostName.Location = New System.Drawing.Point(22, 20)
        Me.LBHostName.Name = "LBHostName"
        Me.LBHostName.Size = New System.Drawing.Size(128, 13)
        Me.LBHostName.TabIndex = 3
        Me.LBHostName.Text = "Client Auto Domain Name"
        '
        'TB_Password
        '
        Me.TB_Password.Location = New System.Drawing.Point(156, 72)
        Me.TB_Password.Name = "TB_Password"
        Me.TB_Password.Size = New System.Drawing.Size(179, 20)
        Me.TB_Password.TabIndex = 2
        Me.TB_Password.Text = "CAdemo123"
        '
        'TB_User
        '
        Me.TB_User.Location = New System.Drawing.Point(157, 46)
        Me.TB_User.Name = "TB_User"
        Me.TB_User.Size = New System.Drawing.Size(178, 20)
        Me.TB_User.TabIndex = 1
        Me.TB_User.Text = "administrator"
        '
        'TB_HostName
        '
        Me.TB_HostName.Location = New System.Drawing.Point(157, 20)
        Me.TB_HostName.Name = "TB_HostName"
        Me.TB_HostName.Size = New System.Drawing.Size(178, 20)
        Me.TB_HostName.TabIndex = 0
        Me.TB_HostName.Text = "lecri01-142dm"
        '
        'ButtonExit
        '
        Me.ButtonExit.Location = New System.Drawing.Point(227, 275)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(75, 47)
        Me.ButtonExit.TabIndex = 7
        Me.ButtonExit.Text = "Exit Application"
        Me.ButtonExit.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(130, 20)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(360, 357)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.GBoxCredentials)
        Me.Controls.Add(Me.GBMode)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Validate Credentials"
        Me.GBMode.ResumeLayout(False)
        Me.GBMode.PerformLayout()
        Me.GBoxCredentials.ResumeLayout(False)
        Me.GBoxCredentials.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GBMode As GroupBox
    Friend WithEvents RBexport As RadioButton
    Friend WithEvents RBImport As RadioButton
    Friend WithEvents GBoxCredentials As GroupBox
    Friend WithEvents LBpassword As Label
    Friend WithEvents LBUser As Label
    Friend WithEvents LBHostName As Label
    Friend WithEvents TB_Password As TextBox
    Friend WithEvents TB_User As TextBox
    Friend WithEvents TB_HostName As TextBox
    Friend WithEvents LabelInvalid As Label
    Friend WithEvents ButtonValidate As Button
    Friend WithEvents ButtonExit As Button
    Friend WithEvents TextBox1 As TextBox
End Class
