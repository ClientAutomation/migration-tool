﻿
Imports System
    Imports System.IO
    Imports System.Net
    Imports System.Collections
    Imports System.String
    Imports System.ComponentModel
    Imports System.Windows.Forms
    Imports System.Data.SqlClient
    Imports System.Runtime.InteropServices '   DllImport
    Imports System.Security.Principal '  WindowsImpersonationContext
    Imports System.Security.Permissions
Imports System.Text
Imports System.Diagnostics

Module Client_Auto_functions
        Public dsms As New clientauto.DSMWebServiceAPIService
        Public SessionID As New Object 'web service session ID
        Public NewPackageUUID As String
        Public NewVolumeUUID As String

    Public packageinfo(10000, 3) 'name,version,uuid
    Public RollupGroupUUID As String
    Public SoftwareGroupNames(10000, 4) As String 'name ,uuid
    Public TotalpackageCount As Integer = 0 'all softwarepackages
    Public BeginningQueryGroupPointer As Integer = 0

    Public BeginningGroupPointer As Integer = 0
    Public BeginningItemPointer As Integer = 0
    Public BeginningSoftwareGroupPointer As Integer = 0
    Public TotalSoftwarGroupCount As Integer = 0
    Public SoftwareGroupCount As Integer = 0 ' for sofwaregroupnames

    Public QueryGroupNames(10000, 2) As String 'name,uuid
    Public TotalQueryGroupCount As Integer = 0 'for querygroupnames

    Public QueryNames(10000, 2) As String 'name,uuid
    Public QueryCount As Integer = 0 'for querynames

    Public CompGroupNames(10000, 7) As String 'groupLabel, groupUUID, queryLabel, queryUUID, engineLabel, evaluationFrequency
    Public TotalUnitGroupCount As Integer = 0 'for computergroupnames

    Public ComputerNames(10000, 2) As String
    Public TotalComputerCount As Integer = 0 'for computernames

    Public EngineInstanceList(20) As String
    Public EngineCount As Integer = 0
    Public textfile As System.IO.StreamWriter
    Public textfile1 As System.IO.StreamWriter
    Public MySelectedNode As TreeNode()





    Function WSLogin(HostName As String) As String 'called by startup.validate to see if credentials are valid

            ' UpdateLog(1, "common.WSlogin", "Attemping to get sessionID from " + HostName, 0)
            SessionID = ""



            Try
                dsms.Url = "http://" + HostName + "/DSM_Webservice/mod_gsoap.dll"
                Dim PasswordENC As String = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(Form1.TB_Password.Text))
                Dim userenc As String = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes("winnt://" + Form1.TB_HostName.Text + "/" + Form1.TB_User.Text))
                ' UpdateLog(1, "common.WSlogin", "Trying To login To WebServices On Server " + HostName + " as user " + tmpuser, 0)
                SessionID = dsms.Login2(userenc, PasswordENC, HostName)
            Catch ex As Exception
                MessageBox.Show("Trying To login To WebServices On Server " + HostName + vbCrLf + "as user " + "winnt://" + Form1.TB_HostName.Text + "/" + Form1.TB_User.Text + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                ' UpdateLog(1, "common.WSlogin", "Trying To login To WebServices On Server " + HostName + "as user " + tmpuser + "Process returned the following error" + ex.Message, 2)
                Return "NOTOK"

            End Try
            'UpdateLog(1, "common.WSlogin", "Obtained sessionid " + SessionID.ToString, 0)

            Return SessionID.ToString
        End Function

        Function wslogout() As String
            Try
                dsms.Logout(SessionID)
            Catch ex As Exception
                Return "NotOK"
            End Try
            Return "OK"
        End Function

        Function WSCreateSDPackage(PackageName As String, PackageVersion As String) As String
            Dim CreateSoftwarePackageProperties As New clientauto.CreateSoftwarePackageProperties3()
            CreateSoftwarePackageProperties.softwarePackageName = PackageName
            CreateSoftwarePackageProperties.softwarePackageVersion = PackageVersion
            CreateSoftwarePackageProperties.packageType = 10

            Try
                NewPackageUUID = dsms.CreateSoftwarePackage3(SessionID, CreateSoftwarePackageProperties, False)
            Catch ex As Exception
                MessageBox.Show("FAILED TRYING TO CREATE New SOFTWARE PACKAGE RETURNED THE FOLLOWING ERROR" + vbCrLf + ex.Message + vbCrLf + "PackageName=" + PackageName + " Packageversion " + PackageVersion)
                Return "NOT ok"
            End Try
            Return "ok"


        End Function

        Function WSCreateSoftwarePackageVolume() As String
            Dim CreateSoftwareVolumeProperties As New clientauto.CreateSoftwarePackageVolumeProperties()
            CreateSoftwareVolumeProperties.softwarePackageId = NewPackageUUID
            CreateSoftwareVolumeProperties.softwarePackageIdSupplied = True
            CreateSoftwareVolumeProperties.volumeName = "vol1"
            CreateSoftwareVolumeProperties.volumeNameSupplied = True
            Try
                NewVolumeUUID = dsms.CreateSoftwarePackageVolume(SessionID, CreateSoftwareVolumeProperties)
            Catch ex As Exception
                MessageBox.Show("FAILED TRYING TO CREATE New SOFTWARE PACKAGE VOLUME RETURNED THE FOLLOWING ERROR" + vbCrLf + ex.Message)
                Return "NOT ok"
            End Try
            Return "ok"

        End Function

        Function wsCopyElementsToSoftwarePackageVolume(baseDirectory As String, Filelist() As String) As String

            Dim array(Filelist.Count - 1) As clientauto.FileSystemElementPath
            Dim j As Integer = 0
            For j = 0 To Filelist.Count - 1
                array(j) = New clientauto.FileSystemElementPath() With {
        .elementPath = baseDirectory,
        .elementName = Filelist(j)}
                My.Computer.FileSystem.WriteAllText("C:\customintellirollup.log", Filelist(j), True)




            Next j

            Try
                'If Form1.TB_HostName.Text = System.Environment.MachineName Then
                'dsms.CopyElementsToSoftwarePackageVolume(SessionID, NewVolumeUUID, ".", array)
                'Else
                dsms.CopyElementsToSoftwarePackageVolume2(SessionID, NewVolumeUUID, ".", False, array)
                'End If
            Catch ex As Exception
                My.Computer.FileSystem.WriteAllText("C:\customintellirollup.log", ex.Message, True)
                MessageBox.Show("FAILED TRYING TO ADD FILES TO New SOFTWARE PACKAGE VOLUME RETURNED THE FOLLOWING ERROR" + vbCrLf + ex.Message)

                Return "NOT ok"
            End Try
            Return "ok"
        End Function

        Function WSCreateSoftwareProcedure(ProcToRun As String, subpath As String, proctype As String) As String

            Dim SoftwarePackageckageOperationMask5 As New clientauto.SoftwarePackageProcedureOperationMask5()
            Dim softwarepackageproceduremanagementtypemask As New clientauto.SoftwarePackageProcedureManagementTypeMask()
            softwarepackageproceduremanagementtypemask.sd = True
            'softwarepackageproceduremanagementtypemask.sm = True Or False

            Dim procedureUUID As String
            Dim CreateSoftwarepackageProcedureProperties5 As New clientauto.CreateSoftwarePackageProcedureProperties5
            CreateSoftwarepackageProcedureProperties5.procToRun = ProcToRun
            CreateSoftwarepackageProcedureProperties5.softwarePackageVolumeId = NewVolumeUUID
            CreateSoftwarepackageProcedureProperties5.softwarePackageVolumeIdSupplied = True
            CreateSoftwarepackageProcedureProperties5.softwarePackageProcedureType = clientauto.SoftwarePackageProcedureType.IPS
            CreateSoftwarepackageProcedureProperties5.subPath = subpath
            CreateSoftwarepackageProcedureProperties5.subPathSupplied = True
            CreateSoftwarepackageProcedureProperties5.parametersSupplied = True

            CreateSoftwarepackageProcedureProperties5.operationMaskSupplied = True
            CreateSoftwarepackageProcedureProperties5.operatingSystemType = "196608"

            CreateSoftwarepackageProcedureProperties5.managementTypeMask = softwarepackageproceduremanagementtypemask




            If proctype = "Install" Then
                CreateSoftwarepackageProcedureProperties5.softwarePackageProcedureName = "Install"
                CreateSoftwarepackageProcedureProperties5.softwarePackageProcedureTask = clientauto.SoftwarePackageProcedureTask.INSTALL
                CreateSoftwarepackageProcedureProperties5.parameters = "$rf $up"
                SoftwarePackageckageOperationMask5.rollupInstall = True
                SoftwarePackageckageOperationMask5.autoDeliverItem = True
                SoftwarePackageckageOperationMask5.background = True
                SoftwarePackageckageOperationMask5.defaultItemProc = True
                SoftwarePackageckageOperationMask5.offline = False
                CreateSoftwarepackageProcedureProperties5.operationMask = SoftwarePackageckageOperationMask5
                CreateSoftwarepackageProcedureProperties5.managementTypeMask = softwarepackageproceduremanagementtypemask
                CreateSoftwarepackageProcedureProperties5.managementTypeMaskSupplied = True
            Else
                CreateSoftwarepackageProcedureProperties5.softwarePackageProcedureName = "Configure"
                CreateSoftwarepackageProcedureProperties5.softwarePackageProcedureTask = clientauto.SoftwarePackageProcedureTask.CONFIGURE
                CreateSoftwarepackageProcedureProperties5.parameters = "$rf CONFIGURE"
                SoftwarePackageckageOperationMask5.rollupConfigure = True
            End If
            Try
                procedureUUID = dsms.CreateSoftwarePackageProcedure5(SessionID, NewPackageUUID, CreateSoftwarepackageProcedureProperties5)
            Catch ex As Exception
                MessageBox.Show("FAILED TRYING TO Create SOFTWARE PACKAGE PROCEDURE RETURNED THE FOLLOWING ERROR" + vbCrLf + ex.Message + vbCrLf + " looking for procedure " + ProcToRun + " in path " + subpath)
            End Try
            Return "ok"
        End Function

        Function WSSealSoftwarePackage() As String
            Dim ArrayOfSoftwarePackages(0) As String
            ArrayOfSoftwarePackages(0) = NewPackageUUID
            Try
                dsms.SealSoftwarePackages(SessionID, ArrayOfSoftwarePackages)
            Catch ex As Exception
                MessageBox.Show("FAILED TRYING TO SEAL SOFTWARE PACKAGE RETURNED THE FOLLOWING ERROR" + vbCrLf + ex.Message)
                Return "NOT OK"
            End Try
            Return "ok"
        End Function

    Function WSGetAllSoftware(SoftwarePackageGroupID As String, PopulateMaster As Boolean, ByRef package() As String) As String  'called by startup.validate once credentials have been validate 

        Dim StrArray() As String
        Dim WSoutSoftwarePackageList() As clientauto.SoftwarePackageProperties2
        Dim ReturnText As String = Nothing
        Dim Failed As Boolean = False
        Dim index As Long = 0
        Dim numrequired As Long
        Dim TotalCount As Long = Nothing
        Dim j As Integer
        Dim packpropreq As New clientauto.SoftwarePackagePropertiesRequired With {
        .softwarePackageNameRequired = True,
        .softwarePackageVersionRequired = True,
        .softwarePackageIdRequired = True}

        Dim sortprop As clientauto.SoftwarePackageProperty = clientauto.SoftwarePackageProperty.SDPKGNAME

        Dim packfilter(0) As clientauto.SoftwarePackageFilter
        packfilter(0) = New clientauto.SoftwarePackageFilter() With {
        .swPkgProperty = clientauto.SoftwarePackageProperty.SDPKGNAME,
        .condition = clientauto.FILTERCONDITION.FILTERWILDCARDEQ,
        .searchString = "*"}

        Dim ArrayOfSoftwarePackageFilter As clientauto.ArrayOfSoftwarePackageFilter = New clientauto.ArrayOfSoftwarePackageFilter With {
        .filter = packfilter,
        .matchAll = True}

        Try

            WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, SoftwarePackageGroupID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)
        Catch ex As Exception
            MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)

            Return "NOTOK"
            Exit Function
        End Try
        If TotalCount = 0 Then


            Return "NoPackages"
            Exit Function
        End If
        numrequired = TotalCount
        ReDim package(TotalCount)
        Try
            WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, SoftwarePackageGroupID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)

        Catch ex As Exception

            MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)

            Return "NOTOK"
            Exit Function
        End Try


        If PopulateMaster = True Then
            TotalpackageCount = TotalCount
            For j = 0 To TotalpackageCount - 1
                packageinfo(j, 0) = WSoutSoftwarePackageList(j).softwarePackageName
                packageinfo(j, 1) = WSoutSoftwarePackageList(j).softwarePackageVersion
                packageinfo(j, 2) = packageinfo(j, 0) + "'" + packageinfo(j, 1)
                packageinfo(j, 3) = WSoutSoftwarePackageList(j).softwarePackageId
            Next
        End If
        If TotalCount >= 0 Then


            For j = 0 To TotalCount - 1
                package(j) = WSoutSoftwarePackageList(j).softwarePackageName + "'" + WSoutSoftwarePackageList(j).softwarePackageVersion
            Next

            Return "OK"

        End If


    End Function

    Function WSCreateRollupGroup(GroupName As String) As String
            Dim createPatchRollupProperties As New clientauto.CreatePatchRollupProperties With {
            .name = GroupName}
            Try
                RollupGroupUUID = dsms.CreatePatchRollup(SessionID, createPatchRollupProperties)
            Catch ex As Exception
                MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return "NOTOK"
                Exit Function
            End Try

            Return "ok"
        End Function
        Function WSLinkSoftwareToGroup(UUIDArray() As String) As String
            Try
                dsms.LinkSoftwarePackagesToSoftwarePackageGroup(SessionID, RollupGroupUUID, UUIDArray)
            Catch ex As Exception
                MessageBox.Show("Trying to add packages to group" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return "NOTOK"
                Exit Function
            End Try



            Return "ok"

        End Function
    Function WSGetSoftwareGroups(GroupUUID As String) As Integer
        Dim handle As Long
        Dim Totalcount As Long
        Dim k As Long
        Dim SoftwarePackageGroupProperties() As clientauto.SoftwarePackageGroupProperties
        Dim SoftwarePackageGroupPropertiesRequired As New clientauto.SoftwarePackageGroupPropertiesRequired
        SoftwarePackageGroupPropertiesRequired.nameRequired = True
        SoftwarePackageGroupPropertiesRequired.softwarePackageGroupIdRequired = True
        'SoftwarePackageGroupPropertiesRequired.softwarePackageGroupPropertyRequired = True
        SoftwarePackageGroupPropertiesRequired.attribMaskRequired = True
        Try
            dsms.OpenSoftwarePackageGroupList(SessionID.ToString, GroupUUID, SoftwarePackageGroupPropertiesRequired, handle, True, Totalcount, True)
        Catch ex As Exception
            MessageBox.Show("Trying to OpenSoftwarePackageGroupList" + vbCrLf + "groupuuid=" + GroupUUID + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try

        If Totalcount > 0 Then
            Try
                SoftwarePackageGroupProperties = dsms.GetSoftwarePackageGroups(SessionID.ToString, handle, Totalcount)
            Catch ex As Exception
                dsms.CloseSoftwarePackageGroupList(SessionID.ToString, handle)
                MessageBox.Show("Trying to GetSoftwarePackageGroupList" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return -1
                Exit Function
            End Try
        End If

        Try
            dsms.CloseSoftwarePackageGroupList(SessionID.ToString, handle)
        Catch ex As Exception
            MessageBox.Show("Trying to CloseSoftwarePackageGroupList" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        If Totalcount > 0 Then
            SoftwarePackageGroupPropertiesRequired.softwarePackageGroupPropertyRequired = True

            Dim l As String
            For k = 0 To Totalcount - 1
                l = SoftwarePackageGroupProperties(k).name
                If Left(SoftwarePackageGroupProperties(k).name, 1) = "$" Then
                    l = SoftwarePackageGroupProperties(k).name
                    l = Mid(l, InStr(l, "%") + 1)
                    l = Left(l, Len(l) - 1)

                End If
                SoftwareGroupNames(BeginningGroupPointer + k, 0) = l
                SoftwareGroupNames(BeginningGroupPointer + k, 1) = SoftwarePackageGroupProperties(k).softwarePackageGroupId

                TotalSoftwarGroupCount = TotalSoftwarGroupCount + 1
            Next
        Else
            Return 0
        End If

        Return Totalcount
    End Function

    Function WSGetQueryGroups(QueryUUID As String) As Integer
        Dim found As Boolean
        Dim Index As Long = 0
        Dim NumRequired As Long = 0
        Dim totalNumfolders As Long
        Dim queryfolderproperties() As clientauto.QueryFolderProperties
        Dim m As Integer
        Try
            queryfolderproperties = dsms.GetQueryFolders(SessionID.ToString, QueryUUID, index, NumRequired, totalNumfolders)
        Catch ex As Exception
            MessageBox.Show("Trying to Get Number of Query Groups" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        NumRequired = totalNumfolders
        Try
            queryfolderproperties = dsms.GetQueryFolders(SessionID.ToString, QueryUUID, index, NumRequired, totalNumfolders)
        Catch ex As Exception
            MessageBox.Show("Trying to Get get list of query groups" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        If NumRequired > 0 Then
            For m = 0 To totalNumfolders - 1
                found = False
                For n = 0 To TotalQueryGroupCount - 1
                    If queryfolderproperties(m).folderName = QueryGroupNames(n, 0) Then
                        found = True
                        Exit For

                    End If
                Next
                If found = False Then
                    QueryGroupNames(TotalQueryGroupCount, 0) = queryfolderproperties(m).folderName
                    QueryGroupNames(TotalQueryGroupCount, 1) = queryfolderproperties(m).folderId
                    TotalQueryGroupCount = TotalQueryGroupCount + 1
                End If
            Next

            Return totalNumfolders
        Else
            Return 0
        End If

    End Function
    Function WSGetAllQueries() As Integer
        Dim handle As Long
        Dim totalnum As Long
        Dim rtn As Boolean
        Dim querypropertiesrequired As New clientauto.QueryPropertiesRequired With {
            .queryIdRequired = True,
            .queryNameRequired = True
            }
        Dim queryproperties() As clientauto.QueryProperties
        Dim m As Integer
        Try
            dsms.OpenQueryList(SessionID.ToString, querypropertiesrequired, handle, True, totalnum, False)
        Catch ex As Exception
            MessageBox.Show("Trying to OpenQueryList in WSGetAllQueries" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        Try
            queryproperties = dsms.GetQueries(SessionID.ToString, handle, totalnum)
        Catch ex As Exception
            dsms.CloseQueryList(SessionID.ToString, handle)
            MessageBox.Show("Trying to GetQueries in WSGetAllQueries" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
        Exit Function
        End Try

        Try
            dsms.CloseQueryList(SessionID.ToString, handle)
        Catch ex As Exception
            MessageBox.Show("Trying to CloseQueryList in WSGetAllQueries" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
        Exit Function
        End Try
        For m = 0 To totalnum - 1
            QueryNames(m, 0) = queryproperties(m).queryName
            QueryNames(m, 1) = queryproperties(m).queryId
            QueryCount = QueryCount + 1
        Next
        Return 0
    End Function

    Function WSGetQueriesInGroup(GroupID As Long, ByRef qnames() As String) As Integer
        Dim m As Integer
        Dim queryfilter(0) As clientauto.QueryFilter
        queryfilter(0) = New clientauto.QueryFilter() With {
            .queryProperty = clientauto.QueryProperty.QUERYLABEL,
            .filterCondition = clientauto.QueryFilterCondition.QUERYFILTERWILDCARDEQ,
            .searchString = "*"}

        Dim arrayofqueryfilter As clientauto.ArrayOfQueryFilter = New clientauto.ArrayOfQueryFilter With {
            .filter = queryfilter,
            .matchAll = True}
        Dim sort As clientauto.QueryProperty = clientauto.QueryProperty.QUERYLABEL
        Dim numrequired As Long = 0
        Dim totalnum As Long
        Dim queryproperties2() As clientauto.QueryProperties2
        Try
            queryproperties2 = dsms.GetQueries2(SessionID.ToString, GroupID, arrayofqueryfilter, sort, True, 0, numrequired, totalnum)
        Catch ex As Exception
            MessageBox.Show("Trying to Get number of queries in the group in WSGetQueriesInGroup" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        If totalnum > 0 Then
            numrequired = totalnum
            Try
                queryproperties2 = dsms.GetQueries2(SessionID.ToString, GroupID, arrayofqueryfilter, sort, True, 0, numrequired, totalnum)
            Catch ex As Exception
                MessageBox.Show("Trying to Get queries in the group in WSGetQueriesInGroup" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return -1
                Exit Function
            End Try
            ReDim qnames(totalnum)
            For m = 0 To totalnum - 1
                qnames(m) = queryproperties2(m).queryName

            Next
        End If

        Return totalnum

    End Function

    Function WSGetGroupsInGroup(GroupUUID As String, ParentName As String) As Integer

        Dim m As Integer
        Dim handle As Long
        Dim TotalCount As Long
        Dim UnitGroupPropertiesRequired As New clientauto.UnitGroupPropertiesRequired With {
            .groupUUIDRequired = True,
            .groupLabelRequired = True,
            .queryLabelRequired = True,
            .queryUUIDRequired = True,
            .engineLabelRequired = True,
            .evaluationFrequenceRequired = True,
            .groupFlagRequired = True
        }
        Dim UnitGroupProperties() As clientauto.UnitGroupProperties
        Try
            dsms.OpenUnitGroupUnitGroupMembersList(SessionID.ToString, GroupUUID, UnitGroupPropertiesRequired, handle, True, TotalCount, True)
        Catch ex As Exception
            MessageBox.Show("Trying to OpenUnitGroupUnitGroupMembersList in WSGetGroupsInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try


        If TotalCount > 0 Then
            Try
                UnitGroupProperties = dsms.GetUnitGroupUnitGroupMembers(SessionID.ToString, handle, TotalCount)
            Catch ex As Exception
                dsms.CloseUnitGroupUnitGroupMembersList(SessionID.ToString, handle)
                MessageBox.Show("Trying to GetUnitGroupUnitGroupMembersList in WSGetGroupsInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return -1
                Exit Function
            End Try
        End If
        Try
            dsms.CloseUnitGroupUnitGroupMembersList(SessionID.ToString, handle)
        Catch ex As Exception
            MessageBox.Show("Trying to OpenUnitGroupUnitGroupMembersList in WSGetGroupsInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        If TotalCount > 0 Then
            Dim pointer1 As Integer = 0

            For m = 0 To TotalCount - 1

                If InStr(UnitGroupProperties(m).groupLabel, "$") < 1 Then
                    CompGroupNames(BeginningGroupPointer + pointer1, 0) = UnitGroupProperties(m).groupLabel
                    CompGroupNames(BeginningGroupPointer + pointer1, 1) = UnitGroupProperties(m).groupUUID
                    CompGroupNames(BeginningGroupPointer + pointer1, 2) = UnitGroupProperties(m).queryLabel
                    CompGroupNames(BeginningGroupPointer + pointer1, 3) = UnitGroupProperties(m).queryUUID
                    CompGroupNames(BeginningGroupPointer + pointer1, 4) = UnitGroupProperties(m).groupFlag
                    CompGroupNames(BeginningGroupPointer + pointer1, 5) = UnitGroupProperties(m).engineLabel
                    CompGroupNames(BeginningGroupPointer + pointer1, 6) = UnitGroupProperties(m).evaluationFrequency
                    CompGroupNames(BeginningGroupPointer + pointer1, 7) = ParentName

                    If UnitGroupProperties(m).queryLabel <> "" Then
                        CompGroupNames(BeginningGroupPointer + pointer1, 0) = UnitGroupProperties(m).groupLabel + "| Query=" + UnitGroupProperties(m).queryLabel
                    End If
                    pointer1 = pointer1 + 1
                    TotalUnitGroupCount = TotalUnitGroupCount + 1
                Else
                    If TotalCount > 0 Then
                        TotalCount = TotalCount - 1
                    End If
                End If
            Next
        End If



        Return TotalCount
    End Function
    Function WSLinkUnitGroup(UnitGroupName As String, GroupToBeLinked() As String)
        Try
            dsms.LinkUnitGroupsToUnitGroupByName(SessionID, UnitGroupName, GroupToBeLinked)
            Return "OK"
        Catch ex As Exception
            MessageBox.Show("Trying to LinkUnitGrouptoUnitGroupByName in WSLinkUnitGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOT OK"
            Exit Function
        End Try
    End Function
    Function WSGetAllComputerUUID() As String
        Dim SysGroupName As clientauto.SystemGroup = clientauto.SystemGroup.COALLCOMPUTERSUSERSGROUP
        Try
            Return dsms.GetSystemGroupUUID(SessionID.ToString, SysGroupName)
        Catch ex As Exception
            MessageBox.Show("Trying to GetSystemGroupUUID in WSGetSystemGroupUUID " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOT OK"
            Exit Function
        End Try

    End Function
    Function WSGetComputersInGroup(groupUUID As String) As Integer
        Dim M As Integer
        Dim totalcount As Long
        Dim handle As Long
        Dim computerpropertiesrequired As New clientauto.ComputerPropertiesRequired With {
            .computerHostNameRequired = True,
            .computerUUIDRequired = True}

        Dim arrayofcomputerpropertyfilter(0) As clientauto.ComputerPropertyFilter
        arrayofcomputerpropertyfilter(0) = New clientauto.ComputerPropertyFilter() With {
        .computerProperty = clientauto.ComputerProperty.COMPUTERHOSTNAME,
        .searchString = "*"}






        Dim computerproperties() As clientauto.ComputerProperties
        Try
            dsms.OpenUnitGroupComputerMembersList(SessionID.ToString, groupUUID, arrayofcomputerpropertyfilter, computerpropertiesrequired, handle, True, totalcount, True)
        Catch ex As Exception
            MessageBox.Show("OpenUnitGroupComputerMembersList in WSGetComputersInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return -1
            Exit Function
        End Try
        If totalcount > 0 Then
            Try
                computerproperties = dsms.GetUnitGroupComputerMembers(SessionID.ToString, handle, totalcount)
            Catch ex As Exception
                dsms.CloseUnitGroupComputerMembersList(SessionID.ToString, handle)
                MessageBox.Show("GetUnitGroupComputerMembersList in WSGetComputersInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return -1
                Exit Function
            End Try


        End If
        Try
            dsms.CloseUnitGroupComputerMembersList(SessionID.ToString, handle)
        Catch ex As Exception
            dsms.CloseUnitGroupComputerMembersList(SessionID.ToString, handle)
            MessageBox.Show("CloseUnitGroupComputerMembersList in WSGetComputersInGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOT OK"
            Exit Function
        End Try
        If totalcount > 0 Then
            For M = 0 To totalcount - 1
                ComputerNames(BeginningItemPointer + M, 0) = computerproperties(M).computerHostName
                ComputerNames(BeginningItemPointer + M, 1) = computerproperties(M).computerHostUUID
                TotalComputerCount = TotalComputerCount + 1
            Next

        End If
        Return totalcount
    End Function

    Function wsGetQuery(QuerryUUID As String) As String()
        Dim querytype As clientauto.QueryType
        Dim fragment(0) As clientauto.QueryFragment2
        Dim queryExport(12) As String
        Dim querypropertiesrequired As New clientauto.QueryPropertiesRequired3 With {
            .queryTableRequired = True,
            .queryNameRequired = True,
            .queryTableLabelPrimaryKeyRequired = True,
            .queryTableLabelSecondaryKeyRequired = True,
            .queryTableLabelFieldRequired = True,
            .queryFragmentsRequired = True,
            .queryTypeRequired = True,
            .queryIdRequired = True
            }
        Dim queryproperties3 As New clientauto.QueryProperties3
        Try
            queryproperties3 = dsms.GetQuery2(SessionID.ToString, QuerryUUID, querypropertiesrequired)
        Catch ex As Exception

            MessageBox.Show("GetQuery2 in WSGETQuery" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            queryExport(0) = "Not OK"
            Return queryExport
            Exit Function
        End Try
        queryExport(0) = queryproperties3.queryName
        queryExport(1) = queryproperties3.queryTable
        QueryExport(2) = queryproperties3.queryTableLabelPrimaryKey
        QueryExport(3) = queryproperties3.queryTableLabelSecondaryKey
        QueryExport(4) = queryproperties3.queryTableLabelField
        queryExport(5) = queryproperties3.queryType

        fragment(0) = queryproperties3.queryFragments(0)

        queryExport(6) = fragment(0).linkQueryName
        queryExport(7) = fragment(0).pseudoStatement
        queryExport(8) = fragment(0).queryFragmentType
        queryExport(9) = fragment(0).searchRecursive
        queryExport(10) = fragment(0).searchRecursiveSupplied
        queryExport(11) = fragment(0).statement


        Return queryExport

    End Function

    Function WSExportSDPackage(PackageUUID As String, ExportDirectory As String) As String
        Dim exportSWPackageprerties As New clientauto.ExportSoftwarePkgProperties With {
            .targetPath = ExportDirectory,
            .targetOnServer = True,
            .exportAs = clientauto.PackageExportType.SOFTWAREPACKAGE}
        Try
            dsms.ExportSoftwarePackage(SessionID.ToString, PackageUUID, exportSWPackageprerties)
        Catch ex As Exception
            MessageBox.Show("ExportSoftwarwePackage in WSExportSDPackage" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return "OK"
    End Function

    Function WSImportQuery(queryname As String, querytable As String, queryTableLabelField As String, queryTableLabelPrimaryKey As String, queryTableLabelSecondaryKey As String, queryType As String, fragment() As clientauto.QueryFragment2) As String





        Dim CreateQueryProperties2 As New clientauto.CreateQueryProperties2
        CreateQueryProperties2.queryName = queryname
        CreateQueryProperties2.queryNameSupplied = True
        CreateQueryProperties2.queryTable = querytable
        CreateQueryProperties2.queryTableLabelField = queryTableLabelField
        CreateQueryProperties2.queryTableLabelFieldSupplied = True
        CreateQueryProperties2.queryTableLabelPrimaryKey = queryTableLabelPrimaryKey
        CreateQueryProperties2.queryTableLabelPrimaryKeySupplied = True
        CreateQueryProperties2.queryType = queryType
        CreateQueryProperties2.queryTypeSupplied = True
        CreateQueryProperties2.queryTableLabelSecondaryKey = queryTableLabelSecondaryKey
        CreateQueryProperties2.queryTableLabelSecondaryKeySupplied = True
        CreateQueryProperties2.queryFragments2 = fragment
        CreateQueryProperties2.queryFragmentsSupplied = True
        Dim NewQueryUUID As String
        Try
            NewQueryUUID = dsms.CreateQuery2(SessionID.ToString, CreateQueryProperties2)

        Catch ex As Exception
            MessageBox.Show("CreateQuery2 in WSImportQuery" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return NewQueryUUID
    End Function

    Function WSimportPackage(PackPath As String) As String
        Dim packUUID As String
        Dim importSoftwarePackageProperties As New clientauto.ImportSoftwarePackageProperties With {
            .regInfoPath = PackPath + "\reginfo",
            .regInfoPathSupplied = True,
        .sourcePath = PackPath,
        .sourcePathSupplied = True}
        Try
            packUUID = dsms.ImportSoftwarePackage(SessionID.ToString, importSoftwarePackageProperties)
        Catch ex As Exception
            MessageBox.Show("ImportSoftwarePackage in WSImportSoftwarePackage" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return packUUID
    End Function
    Function WSCreateSoftwareGroup(Name As String, ParentUUID As String) As String
        Dim CreateSoftwarepackageGroupPrperties As New clientauto.CreateSoftwarePackageGroupProperties With {
            .name = Name,
            .nameSupplied = True}
        If ParentUUID <> "" Then
            CreateSoftwarepackageGroupPrperties.parentSoftwarePackageGroupId = ParentUUID
            CreateSoftwarepackageGroupPrperties.parentSoftwarePackageGroupIdSupplied = True
        End If

        Dim guuid As String
        Try

            guuid = dsms.CreateSoftwarePackageGroup(SessionID.ToString, CreateSoftwarepackageGroupPrperties)


        Catch ex As Exception
            MessageBox.Show("CreateSoftwarePackageGroup in WSCreateSoftwarePackageGroup" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return guuid
    End Function

    Function WSLinkSoftwarGroupToGroup(Name As String, parentUUID As String) As String
        Dim ArrayOfNames(0) As String
        ArrayOfNames(0) = Name
        Try
            dsms.LinkSoftwarePackageGroupsToSoftwarePackageGroup(SessionID.ToString, parentUUID, ArrayOfNames)
        Catch ex As Exception
            MessageBox.Show("LinkSoftwarePackageGroupsToSoftwarePackageGroup in  WSLinkSoftwareGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return "OK"
    End Function

    Function WSLinkPackageToGroup(Name As String, version As String, Parent As String) As String

        Dim packfilter(0) As clientauto.SoftwarePackageFilter
        packfilter(0) = New clientauto.SoftwarePackageFilter()

        Dim arrayofpackage(0) As clientauto.SoftwarePackage
        arrayofpackage(0) = New clientauto.SoftwarePackage() With {
        .softwarePackageName = Name,
        .softwarePackageVersion = version}
        Try
            dsms.LinkSoftwarePackagesToSoftwarePackageGroupByName(SessionID.ToString, Parent, arrayofpackage)
        Catch ex As Exception
            MessageBox.Show("LinkSoftwarePackagesToSoftwarePackageGroupByName in  WSLinkPackageToGroup " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        Return "OK"

    End Function
    Function WSIsSDGroupInGroup(Name As String, ParentUUID As String) As String

        Dim SoftwarepackageGroupPropertiesRequired As New clientauto.SoftwarePackageGroupPropertiesRequired With {
        .nameRequired = True}
        Dim handle As Long
        Dim NumberOfPackages As Long
        Dim softwarepackagegroupproerties() As clientauto.SoftwarePackageGroupProperties
        Dim c As Integer
        Try
            dsms.OpenSoftwarePackageGroupList(SessionID.ToString, ParentUUID, SoftwarepackageGroupPropertiesRequired, handle, True, NumberOfPackages, True)
        Catch ex As Exception
            MessageBox.Show("OpenSoftwarePackageGroupList in  WSIsSDGroupInGroup  " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "Not OK"
            Exit Function
        End Try
        If NumberOfPackages > 0 Then
            Try
                softwarepackagegroupproerties = dsms.GetSoftwarePackageGroups(SessionID.ToString, handle, NumberOfPackages)

            Catch ex As Exception
                MessageBox.Show("GetSoftwarePackageGroups in  WSIsSDGroupInGroup  " + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
                Return "Not OK"
                Exit Function
            End Try


            For c = 0 To NumberOfPackages - 1
                If softwarepackagegroupproerties(c).name = Name Then
                    Return "Found"
                    Exit Function

                End If
            Next
        End If
        dsms.CloseSoftwarePackageGroupList(SessionID.ToString, handle)
        Return "NotFound"
    End Function

    Function WSISpackageInGroup(Name As String, version As String, ParentUUID As String) As String



        Dim c As Integer
        Dim StrArray() As String
        Dim WSoutSoftwarePackageList() As clientauto.SoftwarePackageProperties2
        Dim ReturnText As String = Nothing
        Dim Failed As Boolean = False
        Dim index As Long = 0
        Dim numrequired As Long
        Dim TotalCount As Long = Nothing
        Dim j As Integer
        Dim packpropreq As New clientauto.SoftwarePackagePropertiesRequired With {
        .softwarePackageNameRequired = True,
        .softwarePackageVersionRequired = True
        }

        Dim sortprop As clientauto.SoftwarePackageProperty = clientauto.SoftwarePackageProperty.SDPKGNAME

        Dim packfilter(0) As clientauto.SoftwarePackageFilter
        packfilter(0) = New clientauto.SoftwarePackageFilter() With {
        .swPkgProperty = clientauto.SoftwarePackageProperty.SDPKGNAME,
        .condition = clientauto.FILTERCONDITION.FILTERWILDCARDEQ,
        .searchString = "*"}


        Dim ArrayOfSoftwarePackageFilter As clientauto.ArrayOfSoftwarePackageFilter = New clientauto.ArrayOfSoftwarePackageFilter With {
        .filter = packfilter,
        .matchAll = True}

        Try

            WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, ParentUUID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)
        Catch ex As Exception
            MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)

            Return "NOTOK"
            Exit Function
        End Try

        If TotalCount > 0 Then
            numrequired = TotalCount

            Try
                WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, ParentUUID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)

            Catch ex As Exception

                MessageBox.Show("Trying to Get list of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)

                Return "NOTOK"
                Exit Function
            End Try

            For c = 0 To TotalCount - 1
                If WSoutSoftwarePackageList(c).softwarePackageName = Name And WSoutSoftwarePackageList(c).softwarePackageVersion = version Then

                    Return "Found"

                    Exit Function
                End If
            Next





        End If

        Return "NotFound"
    End Function


    Function WSCreateUnitGroupbyname(Name As String, Engine As String, QueryLabel As String, period As String, parentName As String) As String
        Dim NewGroupUUID As String
        Dim nullist() As String = Nothing

        Dim createunitgroupproperties As New clientauto.CreateUnitGroupPropertiesByName
        createunitgroupproperties.groupLabel = Name

        If Engine <> "" Then
            createunitgroupproperties.engineName = Engine
            createunitgroupproperties.engineNameSupplied = True
        End If
        If QueryLabel <> "" Then
            createunitgroupproperties.queryName = QueryLabel
            createunitgroupproperties.queryNameSupplied = True
        End If
        If period <> "" Then
            createunitgroupproperties.evaluationPeriod = period
            createunitgroupproperties.evaluationPeriodSupplied = True
        End If

        Try


            NewGroupUUID = dsms.CreateUnitGroupByName(SessionID.ToString, parentName, createunitgroupproperties, nullist, False)
        Catch ex As Exception
            MessageBox.Show("in wsCreateUnitGroupbyName" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)

            Return "NOTOK"
            Exit Function
        End Try
        Return NewGroupUUID

    End Function
    ' Function WSCreateComputer() As String
    'Dim CreateComputerProperties As clientauto.SetComputerProperties
    '   CreateComputerProperties.
    ' End Function

    Function TXtSplitter(wordin As String) As String
        Dim spliter() As String
        Dim Trimchars As Char() = "|"
        spliter = wordin.Split("|")
        TXtSplitter = spliter(0).TrimEnd(Trimchars)
    End Function








End Module
